function showProfile(personNumber) {
    // Hide all sections for all profiles
    document.querySelectorAll('.profile, .portfolio, .experience, .education, .skills, .testimonials').forEach(section => {
        section.classList.add('hidden');
    });

    // Show the selected sections for the chosen profile
    document.getElementById(`profile${personNumber}`).classList.remove('hidden');
    document.getElementById(`portfolio${personNumber}`).classList.remove('hidden');
    document.getElementById(`experience${personNumber}`).classList.remove('hidden');
    document.getElementById(`education${personNumber}`).classList.remove('hidden');
    document.getElementById(`skills${personNumber}`).classList.remove('hidden');
    document.getElementById(`testimonials${personNumber}`).classList.remove('hidden');
}
